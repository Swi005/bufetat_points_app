Farger brukt av Buffetat(Basert på nettsiden deres):
*Header Farge: #F0F5F2
*Tekst Farge : #403E40
*Bakgrunn: #FFFFFF

Monochromatic Colors of #f0f5f2: https://www.color-hex.com/color/f0f5f2
*Mørkest: #c2d6ca
*Mørkere: #d1e1d7
*Mørl: #e1ebe5
*Normal: #f0f5f2



Link til bufetat: https://bestill.bufdir.no/